package vn.card2k;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bstats.bukkit.Metrics;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.entity.ItemFrame;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class Card2k extends JavaPlugin implements TabExecutor, Listener {

    private static final String CARD_API_URL = "https://card2k.net/chargingws/v2";
    private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final String PENDING = "PENDING";
    private static final String PAID = "PAID";
    private static final String EXPIRED = "EXPIRED";
    private static final String CANCELLED = "CANCELLED";
    private static final String DONE = "DONE";
    private static final String FAILED = "FAILED";

    private static class Order {
        String code;
        UUID uuid;
        String name;
        long amount;
        long created;
        String status = PENDING;
        long paidAmount;
        String txId = "";
    }

    private record Match(String txId, long amount) {}

    private record Tx(String id, long amount, String text) {}

    private static class CardOrder {
        String requestId;
        UUID uuid;
        String name;
        String telco;
        long declared;
        String serial = "";
        String code = "";
        long created;
        String status = PENDING;
        boolean sent = true;
        long value;
        long received;
        boolean wrong;     // the sai menh gia
        long credited;     // so VND duoc tinh thuong (sau khi tru phat)
    }

    private record CardSnap(String requestId, String telco, long declared, String serial, String code) {}

    private static class CardPrompt {
        String telco;
        long amount;
        String serial = "";
        boolean needCode = false;
        long created = System.currentTimeMillis();
    }

    /** Ve anh QR len ban do. Khi lenh het han / huy / da thanh toan thi ve de len thanh anh trang co dau X. */
    private static class QrRenderer extends MapRenderer {
        private final BufferedImage image;
        private final BooleanSupplier active;
        private boolean done = false;
        private boolean cleared = false;

        QrRenderer(BufferedImage image, BooleanSupplier active) {
            super(false);
            this.image = image;
            this.active = active;
        }

        @Override
        public void render(MapView map, MapCanvas canvas, Player player) {
            if (!active.getAsBoolean()) {
                if (cleared) return;
                BufferedImage blank = new BufferedImage(128, 128, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = blank.createGraphics();
                g.setColor(java.awt.Color.WHITE);
                g.fillRect(0, 0, 128, 128);
                g.setColor(java.awt.Color.RED);
                g.setStroke(new java.awt.BasicStroke(8f));
                g.drawLine(24, 24, 104, 104);
                g.drawLine(104, 24, 24, 104);
                g.dispose();
                canvas.drawImage(0, 0, blank);
                cleared = true;
                return;
            }
            if (done) return;
            canvas.drawImage(0, 0, image);
            done = true;
        }
    }

    private final Map<String, Order> orders = new LinkedHashMap<>();
    private final Set<String> paidTx = new HashSet<>();
    private final Set<String> ignoredTx = new HashSet<>();
    private final AtomicBoolean polling = new AtomicBoolean(false);
    private final SecureRandom random = new SecureRandom();
    private final Set<String> warnedAuth = ConcurrentHashMap.newKeySet();
    private boolean warnedConfig = false;
    private File ordersFile;
    private NamespacedKey qrKey;
    private int taskId = -1;

    private final Map<String, CardOrder> cards = new LinkedHashMap<>();
    private final Map<UUID, CardPrompt> prompts = new ConcurrentHashMap<>();
    // Nguoi choi dang go so tien tuy y vao chat (uuid -> thoi diem bat dau)
    private final Map<UUID, Long> amountPrompts = new ConcurrentHashMap<>();
    private final AtomicBoolean cardPolling = new AtomicBoolean(false);
    // Chong spam the sai: uuid -> so lan sai / thoi diem sai gan nhat / thoi diem het khoa (ms)
    private final Map<UUID, Integer> cardStrikes = new ConcurrentHashMap<>();
    private final Map<UUID, Long> cardLastFail = new ConcurrentHashMap<>();
    private final Map<UUID, Long> cardLockUntil = new ConcurrentHashMap<>();
    private File cardsFile;
    private int cardTaskId = -1;

    @Override
    public void onEnable() {
        migrateOldData();
        saveDefaultConfig();
        ordersFile = new File(getDataFolder(), "orders.yml");
        qrKey = new NamespacedKey(this, "order");
        cardsFile = new File(getDataFolder(), "cards.yml");
        loadOrders();
        loadCards();
        getCommand("napbank").setExecutor(this);
        getCommand("napbank").setTabCompleter(this);
        getCommand("napthe").setExecutor(this);
        getCommand("napthe").setTabCompleter(this);
        getCommand("card2k").setExecutor(this);
        getCommand("card2k").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        startPolling();
        initPromoFiles();
        startUpdateCheck();
        new Metrics(this, 35713); // bStats
        getLogger().info("Card2k by Hana da bat.");
    }

    /** Lan dau chay sau khi doi ten: chep config / don nap tu plugins/Car2k hoac plugins/CoffeecatBank sang plugins/Card2k. */
    private void migrateOldData() {
        File dataDir = getDataFolder();
        if (new File(dataDir, "config.yml").exists()) return;
        for (String oldName : new String[]{"Car2k", "CoffeecatBank"}) {
            File oldDir = new File(dataDir.getParentFile(), oldName);
            if (!oldDir.isDirectory()) continue;
            dataDir.mkdirs();
            boolean copied = false;
            for (String n : new String[]{"config.yml", "orders.yml", "cards.yml"}) {
                File src = new File(oldDir, n);
                if (!src.isFile()) continue;
                try {
                    java.nio.file.Files.copy(src.toPath(), new File(dataDir, n).toPath(),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    copied = true;
                } catch (IOException e) {
                    getLogger().warning("Khong chep duoc " + n + " tu thu muc cu: " + e.getMessage());
                }
            }
            if (copied) {
                getLogger().info("Da chep cau hinh va du lieu tu plugins/" + oldName + " sang plugins/Card2k.");
                return;
            }
        }
    }

    @Override
    public void onDisable() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
        if (cardTaskId != -1) Bukkit.getScheduler().cancelTask(cardTaskId);
        for (Player pl : Bukkit.getOnlinePlayers()) {
            if (pl.getOpenInventory().getTopInventory().getHolder() instanceof Gui) pl.closeInventory();
        }
        if (updateTaskId != -1) Bukkit.getScheduler().cancelTask(updateTaskId);
        saveOrders();
        saveCards();
        saveDonors();
    }

    private static final List<String> PROVIDERS = List.of("sepay", "thueapibank", "rpay");

    /** Doc cau hinh nha cung cap. Thieu khoa nao thi dung gia tri co san (preset) cua nha do. */
    private String pv(String name, String key, String def) {
        String path = "providers." + name + "." + key;
        if (getConfig().contains(path)) return getConfig().getString(path, def);
        String p = preset(name, key);
        return p != null ? p : def;
    }

    private List<String> pvList(String name, String key) {
        String path = "providers." + name + "." + key;
        if (getConfig().contains(path)) return getConfig().getStringList(path);
        if (name.equals("sepay") && key.equals("headers")) return List.of("Authorization: Bearer {token}");
        return List.of();
    }

    private String urlEnc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    /** Gia tri co san cho SePay va ThueApiBank: nguoi dung chi can dien token (va history-key cho ThueApiBank). */
    private String preset(String name, String key) {
        FileConfiguration c = getConfig();
        switch (name) {
            case "sepay":
                switch (key) {
                    case "url": {
                        String acc = c.getString("providers.sepay.account-number", "");
                        return acc.isBlank() ? "" : "https://my.sepay.vn/userapi/transactions/list?account_number="
                                + urlEnc(acc) + "&limit=50";
                    }
                    case "method": return "GET";
                    case "fields.list-path": return "transactions";
                    case "fields.id": return "id";
                    case "fields.amount": return "amount_in";
                    case "fields.content": return "transaction_content";
                    default: return null;
                }
            case "thueapibank":
                switch (key) {
                    case "url": {
                        // API v2: https://thueapibank.vn/<history-key>/<token>   (vd history-key: historyapicakev2)
                        String hk = c.getString("providers.thueapibank.history-key", "").trim();
                        String tok = c.getString("providers.thueapibank.token", "").trim();
                        hk = hk.replaceFirst("^https?://thueapibank\\.vn/", "");
                        int slash = hk.indexOf('/');
                        if (slash >= 0) hk = hk.substring(0, slash);
                        if (hk.isBlank() || tok.isBlank()) return "";
                        return "https://thueapibank.vn/" + urlEnc(hk) + "/" + urlEnc(tok);
                    }
                    case "method": return "GET";
                    case "fields.list-path": return "transactions";
                    case "fields.id": return "transactionID";
                    case "fields.amount": return "amount";
                    case "fields.content": return "description";
                    case "fields.type": return "type";
                    case "fields.type-in-value": return "IN";
                    default: return null;
                }
            case "rpay":
                switch (key) {
                    case "url": {
                        String tok = c.getString("providers.rpay.token", "");
                        return tok.isBlank() ? "" : "https://rpay.vn/v2/" + urlEnc(tok.trim()) + "?limit=50";
                    }
                    case "method": return "GET";
                    case "fields.list-path": return "transactions";
                    case "fields.id": return "transactionID";
                    case "fields.amount": return "amount";
                    case "fields.content": return "description";
                    case "fields.type": return "type";
                    case "fields.type-in-value": return "IN";
                    default: return null;
                }
            default:
                return null;
        }
    }

    /** Nha cung cap dang BAT (enabled: true) va da dien url. */
    private List<String> activeProviders() {
        List<String> out = new ArrayList<>();
        for (String n : PROVIDERS) {
            if (getConfig().getBoolean("providers." + n + ".enabled", false) && !pv(n, "url", "").isBlank()) out.add(n);
        }
        return out;
    }

    private boolean bankEnabled() {
        return getConfig().getBoolean("bank.enabled", true);
    }

    private boolean cardEnabled() {
        return getConfig().getBoolean("card.enabled", true);
    }

    private boolean cardReady() {
        FileConfiguration c = getConfig();
        return cardEnabled()
                && !c.getString("card.partner-id", "").isBlank()
                && !c.getString("card.partner-key", "").isBlank();
    }

    /** Bao loi dung ly do cho nguoi choi: tat / chua cau hinh. Tra ve true neu dung duoc. */
    private boolean checkCard(Player p) {
        if (!cardEnabled()) { tell(p, "card-disabled", null); return false; }
        if (!cardReady()) { tell(p, "card-not-configured", null); return false; }
        return true;
    }

    private void startPolling() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
        int secs = Math.max(10, getConfig().getInt("provider.poll-seconds", 15));
        taskId = Bukkit.getScheduler().runTaskTimer(this, this::pollTick, 100L, secs * 20L).getTaskId();
        if (cardTaskId != -1) Bukkit.getScheduler().cancelTask(cardTaskId);
        int cs = Math.max(10, getConfig().getInt("card.poll-seconds", 15));
        cardTaskId = Bukkit.getScheduler().runTaskTimer(this, this::cardTick, 140L, cs * 20L).getTaskId();
    }

    // ---------- Luu tru ----------

    private void loadOrders() {
        orders.clear();
        paidTx.clear();
        if (!ordersFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(ordersFile);
        ConfigurationSection s = y.getConfigurationSection("orders");
        if (s == null) return;
        for (String code : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(code);
            if (c == null) continue;
            try {
                Order o = new Order();
                o.code = code;
                o.uuid = UUID.fromString(c.getString("uuid", ""));
                o.name = c.getString("name", "?");
                o.amount = c.getLong("amount");
                o.created = c.getLong("created");
                o.status = c.getString("status", PENDING);
                o.paidAmount = c.getLong("paid-amount");
                o.txId = c.getString("tx-id", "");
                orders.put(code, o);
                if (PAID.equals(o.status) && !o.txId.isEmpty()) paidTx.add(o.txId);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveOrders() {
        YamlConfiguration y = new YamlConfiguration();
        for (Order o : orders.values()) {
            String p = "orders." + o.code + ".";
            y.set(p + "uuid", o.uuid.toString());
            y.set(p + "name", o.name);
            y.set(p + "amount", o.amount);
            y.set(p + "created", o.created);
            y.set(p + "status", o.status);
            y.set(p + "paid-amount", o.paidAmount);
            y.set(p + "tx-id", o.txId);
        }
        try {
            y.save(ordersFile);
        } catch (IOException e) {
            getLogger().warning("Khong luu duoc orders.yml: " + e.getMessage());
        }
    }

    // ---------- Tin nhan ----------

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String raw(String key) {
        return getConfig().getString("messages." + key, key);
    }

    private String fill(String s, Map<String, String> ph) {
        if (ph != null) for (Map.Entry<String, String> e : ph.entrySet()) s = s.replace("{" + e.getKey() + "}", e.getValue());
        return s;
    }

    private void tell(CommandSender to, String key, Map<String, String> ph) {
        to.sendMessage(color(raw("prefix") + fill(raw(key), ph)));
    }

    private void line(CommandSender to, String key, Map<String, String> ph) {
        to.sendMessage(color(fill(raw(key), ph)));
    }

    private String money(long v) {
        return String.format(Locale.US, "%,d", v).replace(',', '.');
    }

    // ---------- Lenh ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("napthe")) {
            handleNapThe(sender, args);
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("khuyenmai")) {
            showPromos(sender, args.length > 0 ? args[0] : null);
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("card2k")) {
            String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
            if (!sub.equals("reload") && !sub.equals("status") && !sub.equals("pending")
                    && !sub.equals("update") && !sub.equals("testpoint")) {
                sender.sendMessage(color("&eDùng: &f/card2k reload &7| &f/card2k status &7| &f/card2k pending &7| &f/card2k update &7| &f/card2k testpoint <số tiền>"));
                return true;
            }
            // reload / status / pending: xu ly o khoi switch ben duoi (can quyen card2k.admin)
        }
        if (args.length == 0) {
            if (sender instanceof Player gp && gp.hasPermission("card2k.use")) openBankGui(gp);
            else tell(sender, "usage", null);
            return true;
        }
        String a = args[0].toLowerCase(Locale.ROOT);
        switch (a) {
            case "reload":
                if (!sender.hasPermission("card2k.admin")) { tell(sender, "no-permission", null); return true; }
                reloadConfig();
                warnedConfig = false;
                startPolling();
                loadPromoConfig();
                startUpdateCheck();
                tell(sender, "reloaded", null);
                return true;
            case "status":
                if (!sender.hasPermission("card2k.admin")) { tell(sender, "no-permission", null); return true; }
                sender.sendMessage(color("&6Nạp bank: " + (bankEnabled() ? "&aBẬT" : "&cTẮT")));
                for (String n : PROVIDERS) {
                    boolean on = getConfig().getBoolean("providers." + n + ".enabled", false);
                    boolean hasUrl = !pv(n, "url", "").isBlank();
                    sender.sendMessage(color("  &7- &f" + n + ": " + (on ? "&aBẬT" : "&cTẮT") + (on && !hasUrl ? " &e(thiếu thông tin cấu hình)" : "")));
                }
                sender.sendMessage(color("&6Nạp thẻ (Card2K): " + (cardEnabled() ? "&aBẬT" : "&cTẮT")
                        + (cardEnabled() && !cardReady() ? " &e(thiếu partner-id/key)" : "")));
                return true;
            case "update":
                if (!sender.hasPermission("card2k.admin")) { tell(sender, "no-permission", null); return true; }
                sender.sendMessage(color("&7Đang kiểm tra bản mới..."));
                Bukkit.getScheduler().runTaskAsynchronously(this, () -> runUpdateCheck(sender));
                return true;
            case "testpoint":
                if (!sender.hasPermission("card2k.admin")) { tell(sender, "no-permission", null); return true; }
                testPoint(sender, args.length > 1 ? args[1] : null);
                return true;
            case "pending":
                if (!sender.hasPermission("card2k.admin")) { tell(sender, "no-permission", null); return true; }
                int n = 0;
                for (Order o : orders.values()) {
                    if (!PENDING.equals(o.status)) continue;
                    n++;
                    sender.sendMessage(color("&6" + o.code + " &7- &f" + o.name + " &7- &e" + money(o.amount) + "đ"));
                }
                if (n == 0) sender.sendMessage(color("&7Không có lệnh nạp nào đang chờ."));
                return true;
            case "huy":
            case "cancel":
                if (!(sender instanceof Player)) { sender.sendMessage(raw("player-only")); return true; }
                cancelPending((Player) sender);
                return true;
            case "menu":
            case "gui":
                if (!(sender instanceof Player)) { sender.sendMessage(raw("player-only")); return true; }
                if (!sender.hasPermission("card2k.use")) { tell(sender, "no-permission", null); return true; }
                openBankGui((Player) sender);
                return true;
            default:
                break;
        }
        if (!(sender instanceof Player)) { sender.sendMessage(raw("player-only")); return true; }
        if (!sender.hasPermission("card2k.use")) { tell(sender, "no-permission", null); return true; }
        createOrder((Player) sender, args[0]);
        return true;
    }

    private boolean cancelPending(Player p) {
        Order mine = pendingOf(p.getUniqueId());
        if (mine == null) { tell(p, "no-pending", null); return false; }
        mine.status = CANCELLED;
        saveOrders();
        removeQrMaps(p);
        tell(p, "cancelled", null);
        return true;
    }

    private Order pendingOf(UUID id) {
        for (Order o : orders.values()) if (PENDING.equals(o.status) && o.uuid.equals(id)) return o;
        return null;
    }

    private long parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(".", "").replace(",", "").trim();
            long mul = 1;
            if (s.endsWith("k")) { mul = 1000; s = s.substring(0, s.length() - 1); }
            return Long.parseLong(s) * mul;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Co du dieu kien de TAO lenh nap moi (bank bat + co provider bat + co so tai khoan). */
    private boolean configured() {
        FileConfiguration c = getConfig();
        return bankEnabled()
                && !activeProviders().isEmpty()
                && !c.getString("bank.account-number", "").isBlank()
                && !c.getString("bank.bank-id", "").isBlank();
    }

    private boolean checkBank(CommandSender p) {
        if (!bankEnabled()) { tell(p, "bank-disabled", null); return false; }
        if (!configured()) { tell(p, "not-configured", null); return false; }
        return true;
    }

    private void createOrder(Player p, String input) {
        if (!checkBank(p)) return;

        Order existing = pendingOf(p.getUniqueId());
        if (existing != null) {
            tell(p, "order-exists", null);
            showInstructions(p, existing);
            return;
        }

        long amount = parseAmount(input);
        if (amount <= 0) { tell(p, "invalid-amount", null); return; }
        long min = getConfig().getLong("order.min-amount", 10000);
        long max = getConfig().getLong("order.max-amount", 5000000);
        if (amount < min || amount > max) {
            tell(p, "amount-range", Map.of("min", money(min), "max", money(max)));
            return;
        }

        Order o = new Order();
        o.code = newCode();
        o.uuid = p.getUniqueId();
        o.name = p.getName();
        o.amount = amount;
        o.created = System.currentTimeMillis();
        orders.put(o.code, o);
        saveOrders();

        tell(p, "order-created", Map.of("amount", money(amount)));
        showInstructions(p, o);
    }

    private String newCode() {
        String prefix = getConfig().getString("order.prefix", "CC").replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
        while (true) {
            StringBuilder sb = new StringBuilder(prefix);
            for (int i = 0; i < 6; i++) sb.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
            if (!orders.containsKey(sb.toString())) return sb.toString();
        }
    }

    private String qrUrl(Order o, String template) {
        FileConfiguration c = getConfig();
        return "https://img.vietqr.io/image/"
                + URLEncoder.encode(c.getString("bank.bank-id", ""), StandardCharsets.UTF_8) + "-"
                + URLEncoder.encode(c.getString("bank.account-number", ""), StandardCharsets.UTF_8)
                + "-" + template + ".png?amount=" + o.amount
                + "&addInfo=" + URLEncoder.encode(o.code, StandardCharsets.UTF_8)
                + "&accountName=" + URLEncoder.encode(c.getString("bank.account-name", ""), StandardCharsets.UTF_8);
    }

    private void showInstructions(Player p, Order o) {
        FileConfiguration c = getConfig();
        long left = Math.max(1, c.getLong("order.expire-minutes", 30) - (System.currentTimeMillis() - o.created) / 60000L);
        Map<String, String> ph = Map.of(
                "bank", c.getString("bank.bank-display-name", c.getString("bank.bank-id", "")),
                "account", c.getString("bank.account-number", ""),
                "name", c.getString("bank.account-name", ""),
                "amount", money(o.amount),
                "code", o.code,
                "minutes", String.valueOf(left));
        line(p, "info-bank", ph);
        line(p, "info-account", ph);
        if (!c.getString("bank.account-name", "").isBlank()) line(p, "info-name", ph);
        line(p, "info-amount", ph);
        line(p, "info-content", ph);
        line(p, "info-expire", ph);
        line(p, "auto-note", ph);

        if (c.getBoolean("order.give-qr-map", true)) giveQrMap(p, o);

        try {
            p.sendMessage(Component.text(raw("qr-link"), NamedTextColor.AQUA, TextDecoration.UNDERLINED)
                    .clickEvent(ClickEvent.openUrl(qrUrl(o, "compact2"))));
        } catch (Exception ignored) {
        }
    }

    // ---------- Ma QR tren ban do ----------

    private void giveQrMap(Player p, Order o) {
        // Neu da co ban do cua lenh nay thi khong tao them
        if (hasQrMap(p, o.code)) return;
        final UUID id = p.getUniqueId();
        final String url = qrUrl(o, "qr_only");
        final String bin = QrMatrix.bankBin(getConfig().getString("bank.bank-id", ""));
        final String account = getConfig().getString("bank.account-number", "");
        final boolean useLocal = getConfig().getBoolean("order.qr-local", true);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            BufferedImage scaled = null;

            // 1) Tu ve ma VietQR ngay trong server (khong can mang, khong phu thuoc img.vietqr.io)
            if (useLocal && bin != null && !account.isBlank()) {
                try {
                    scaled = QrMatrix.encode(QrMatrix.vietQrPayload(bin, account, o.amount, o.code)).toImage(128);
                } catch (Throwable t) {
                    getLogger().warning("Khong tu ve duoc ma QR, thu tai online: " + t);
                }
            }

            // 2) Du phong: tai anh QR tu img.vietqr.io
            if (scaled == null) {
                try {
                    HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
                    con.setConnectTimeout(8000);
                    con.setReadTimeout(8000);
                    con.setInstanceFollowRedirects(true);
                    con.setRequestProperty("User-Agent", "Mozilla/5.0 (compatible; Card2k)");
                    try {
                        int rc = con.getResponseCode();
                        if (rc != 200) {
                            getLogger().warning("Tai anh QR that bai, ma HTTP " + rc);
                        } else {
                            try (InputStream in = con.getInputStream()) {
                                BufferedImage src = ImageIO.read(in);
                                if (src != null) {
                                    scaled = new BufferedImage(128, 128, BufferedImage.TYPE_INT_RGB);
                                    Graphics2D g = scaled.createGraphics();
                                    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                                    g.setColor(java.awt.Color.WHITE);
                                    g.fillRect(0, 0, 128, 128);
                                    g.drawImage(src, 0, 0, 128, 128, null);
                                    g.dispose();
                                } else {
                                    getLogger().warning("Tai anh QR: khong doc duoc file anh tra ve.");
                                }
                            }
                        }
                    } finally {
                        con.disconnect();
                    }
                } catch (Throwable t) {
                    getLogger().warning("Khong tai duoc anh QR: " + t);
                }
            }
            final BufferedImage img = scaled;
            Bukkit.getScheduler().runTask(this, () -> {
                Player pl = Bukkit.getPlayer(id);
                if (pl == null || !PENDING.equals(o.status)) return;
                if (img == null) { tell(pl, "qr-failed", null); return; }
                try {
                    MapView view = Bukkit.createMap(pl.getWorld());
                    for (MapRenderer r : new ArrayList<>(view.getRenderers())) view.removeRenderer(r);
                    view.addRenderer(new QrRenderer(img, () -> PENDING.equals(o.status)));

                    ItemStack item = new ItemStack(Material.FILLED_MAP);
                    MapMeta meta = (MapMeta) item.getItemMeta();
                    meta.setMapView(view);
                    meta.displayName(Component.text("Mã QR nạp " + money(o.amount) + "đ", NamedTextColor.GOLD)
                            .decoration(TextDecoration.ITALIC, false));
                    meta.lore(List.of(
                            Component.text("Nội dung CK: " + o.code, NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false),
                            Component.text("Cầm lên tay và quét bằng app ngân hàng", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
                    meta.getPersistentDataContainer().set(qrKey, PersistentDataType.STRING, o.code);
                    item.setItemMeta(meta);

                    Map<Integer, ItemStack> left = pl.getInventory().addItem(item);
                    if (left.isEmpty()) {
                        tell(pl, "qr-given", null);
                    } else {
                        tell(pl, "inventory-full", Map.of("amount", String.valueOf(o.amount)));
                    }
                } catch (Throwable t) {
                    getLogger().log(java.util.logging.Level.WARNING, "Khong tao duoc ban do QR", t);
                    tell(pl, "qr-failed", null);
                }
            });
        });
    }

    private String qrCodeOf(ItemStack it) {
        if (it == null || it.getType() != Material.FILLED_MAP || !it.hasItemMeta()) return null;
        ItemMeta m = it.getItemMeta();
        return m.getPersistentDataContainer().get(qrKey, PersistentDataType.STRING);
    }

    private boolean hasQrMap(Player p, String code) {
        for (ItemStack it : p.getInventory().getContents()) {
            if (code.equals(qrCodeOf(it))) return true;
        }
        return false;
    }

    /** Xoa cac ban do QR cua lenh khong con cho thanh toan khoi tui do. */
    private void removeQrMaps(Player p) {
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            String code = qrCodeOf(contents[i]);
            if (code == null) continue;
            Order o = orders.get(code);
            if (o == null || !PENDING.equals(o.status)) p.getInventory().setItem(i, null);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        removeQrMaps(e.getPlayer());
        notifyUpdateOnJoin(e.getPlayer());
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (qrCodeOf(e.getItemDrop().getItemStack()) != null) e.setCancelled(true);
    }

    // ---------- Chong dua ban do QR vao ruong / khung vat pham ----------

    private boolean isQr(ItemStack it) {
        return qrCodeOf(it) != null;
    }

    /** Ban do QR cua lenh khong con cho thanh toan (da huy / het han / da tra). */
    private boolean isStaleQr(ItemStack it) {
        String code = qrCodeOf(it);
        if (code == null) return false;
        Order o = orders.get(code);
        return o == null || !PENDING.equals(o.status);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onQrClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (top.getHolder() instanceof Gui) return;
        Inventory clicked = e.getClickedInventory();
        ItemStack current = e.getCurrentItem();

        // Ban do QR cu: xoa luon khi bam vao
        if (clicked != null && isStaleQr(current)) {
            e.setCurrentItem(null);
            e.setCancelled(true);
            return;
        }
        // Dat ban do dang cam tren con tro vao ruong / ban che tao / ...
        if (clicked != null && clicked == top && isQr(e.getCursor())) {
            e.setCancelled(true);
            return;
        }
        // Shift-click ban do tu tui do sang ruong
        if (e.getClick().isShiftClick() && clicked != null && clicked != top
                && top.getType() != InventoryType.CRAFTING && isQr(current)) {
            e.setCancelled(true);
            return;
        }
        // Phim so / phim F doi cho voi o cua ruong
        if (clicked != null && clicked == top) {
            if (e.getClick() == ClickType.NUMBER_KEY && e.getHotbarButton() >= 0
                    && isQr(e.getWhoClicked().getInventory().getItem(e.getHotbarButton()))) {
                e.setCancelled(true);
                return;
            }
            if (e.getClick() == ClickType.SWAP_OFFHAND
                    && isQr(e.getWhoClicked().getInventory().getItemInOffHand())) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onQrDrag(InventoryDragEvent e) {
        if (!isQr(e.getOldCursor())) return;
        int topSize = e.getView().getTopInventory().getSize();
        for (int slot : e.getRawSlots()) {
            if (slot < topSize) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onQrHopper(InventoryMoveItemEvent e) {
        if (isQr(e.getItem())) e.setCancelled(true);
    }

    /** Mo ruong: don ban do QR cu con sot lai trong do. */
    @EventHandler
    public void onQrOpen(InventoryOpenEvent e) {
        Inventory inv = e.getInventory();
        if (inv.getHolder() instanceof Gui) return;
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isStaleQr(contents[i])) inv.setItem(i, null);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onQrItemFrame(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof ItemFrame)) return;
        if (isQr(e.getPlayer().getInventory().getItem(e.getHand()))) {
            e.setCancelled(true);
            tell(e.getPlayer(), "qr-no-place", null);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onQrArmorStand(PlayerArmorStandManipulateEvent e) {
        if (isQr(e.getPlayerItem())) {
            e.setCancelled(true);
            tell(e.getPlayer(), "qr-no-place", null);
        }
    }

    @EventHandler
    public void onQrDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(this::isQr);
    }

    // ---------- Kiem tra giao dich ----------

    private void pollTick() {
        if (polling.get()) return;
        long expireMs = getConfig().getLong("order.expire-minutes", 30) * 60000L;
        long now = System.currentTimeMillis();
        List<String> codes = new ArrayList<>();
        boolean changed = false;
        for (Order o : orders.values()) {
            if (!PENDING.equals(o.status)) continue;
            if (now - o.created > expireMs) {
                o.status = EXPIRED;
                changed = true;
                Player pl = Bukkit.getPlayer(o.uuid);
                if (pl != null) {
                    tell(pl, "expired", Map.of("code", o.code));
                    removeQrMaps(pl);
                }
            } else {
                codes.add(o.code);
            }
        }
        if (changed) saveOrders();
        if (codes.isEmpty()) return;
        final List<String> active = activeProviders();
        if (active.isEmpty()) {
            if (!warnedConfig) {
                warnedConfig = true;
                getLogger().warning("Khong co nha cung cap bank nao bat (providers.<ten>.enabled: true + url), chua kiem tra giao dich duoc.");
            }
            return;
        }

        polling.set(true);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            List<Tx> txs = new ArrayList<>();
            boolean any = false;
            for (String name : active) {
                try {
                    List<Tx> part = fetch(name);
                    if (part != null) { txs.addAll(part); any = true; }
                } catch (Exception e) {
                    getLogger().warning("Loi goi API " + name + " (" + e.getClass().getSimpleName() + ")");
                }
            }
            final List<Tx> result = any ? txs : null;
            Bukkit.getScheduler().runTask(this, () -> {
                try {
                    if (result == null) return;
                    for (String code : codes) {
                        for (Tx t : result) {
                            if (paidTx.contains(t.id())) continue;
                            if (t.text().contains(code)) {
                                complete(code, new Match(t.id(), t.amount()));
                                break;
                            }
                        }
                    }
                } finally {
                    polling.set(false);
                }
            });
        });
    }

    private List<Tx> fetch(String name) throws IOException {
        FileConfiguration c = getConfig();
        String token = pv(name, "token", "");
        String method = pv(name, "method", "GET").toUpperCase(Locale.ROOT);
        String url = pv(name, "url", "").replace("{token}", URLEncoder.encode(token, StandardCharsets.UTF_8));

        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        try {
            con.setRequestMethod(method);
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("User-Agent", "Card2k");
            for (String h : pvList(name, "headers")) {
                int i = h.indexOf(':');
                if (i <= 0) continue;
                con.setRequestProperty(h.substring(0, i).trim(), h.substring(i + 1).trim().replace("{token}", token));
            }
            con.setConnectTimeout(8000);
            // RPay co the cho toi 90s de tu lam moi phien ngan hang (khuyen nghi >= 60s)
            con.setReadTimeout(name.equals("rpay") ? 65000 : 8000);
            if (method.equals("POST")) {
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                String body = pv(name, "body", "").replace("{token}", token);
                try (OutputStream os = con.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }
            }
            int rc = con.getResponseCode();
            if (rc == 401 || rc == 403) {
                if (warnedAuth.add(name)) {
                    getLogger().warning(name + " tra ve " + rc + ": token sai hoac khong du quyen.");
                }
                return null;
            }
            if (rc >= 300) {
                if (rc != 429) getLogger().warning(name + " tra ve ma " + rc);
                return null;
            }
            warnedAuth.remove(name);
            String bodyText = new String(con.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            return parse(name, JsonParser.parseString(bodyText));
        } finally {
            con.disconnect();
        }
    }

    private List<Tx> parse(String name, JsonElement root) {
        FileConfiguration c = getConfig();
        String fId = pv(name, "fields.id", "id");
        String fAmount = pv(name, "fields.amount", "amount");
        String fContent = pv(name, "fields.content", "description");
        String fType = pv(name, "fields.type", "");
        String typeIn = pv(name, "fields.type-in-value", "in");

        List<Tx> out = new ArrayList<>();
        for (JsonElement el : listOf(root, pv(name, "fields.list-path", ""))) {
            if (!el.isJsonObject()) continue;
            JsonObject t = el.getAsJsonObject();
            if (!fType.isBlank() && !typeIn.equalsIgnoreCase(str(t, fType))) continue;

            Long amount = amountOf(t.get(fAmount));
            if (amount == null || amount <= 0) continue;

            String text = (str(t, fContent) + " " + t.toString()).toUpperCase(Locale.ROOT);
            String id = str(t, fId);
            if (id.isEmpty()) id = "h" + Integer.toHexString(t.toString().hashCode());
            out.add(new Tx(name + ":" + id, amount, text));
        }
        return out;
    }

    private JsonArray listOf(JsonElement root, String path) {
        JsonElement cur = root;
        if (!path.isBlank()) {
            for (String k : path.split("\\.")) {
                if (cur == null || !cur.isJsonObject()) { cur = null; break; }
                cur = cur.getAsJsonObject().get(k.trim());
            }
        }
        return cur != null && cur.isJsonArray() ? cur.getAsJsonArray() : new JsonArray();
    }

    private Long amountOf(JsonElement e) {
        if (e == null || e.isJsonNull()) return null;
        String s = e.getAsString().trim().replace(",", "");
        try {
            return (long) Double.parseDouble(s);
        } catch (NumberFormatException ex) {
            try {
                return (long) Double.parseDouble(s.replace(".", ""));
            } catch (NumberFormatException ex2) {
                return null;
            }
        }
    }

    private String str(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e == null || e.isJsonNull() || !e.isJsonPrimitive() ? "" : e.getAsString();
    }

    // Chay tren main thread
    private void complete(String code, Match m) {
        Order o = orders.get(code);
        if (o == null || !PENDING.equals(o.status)) return;
        if (paidTx.contains(m.txId())) return;

        long min = getConfig().getLong("order.min-amount", 10000);
        if (m.amount() < min) {
            if (ignoredTx.add(m.txId())) {
                getLogger().warning("Giao dich " + m.txId() + " (" + m.amount() + "d) cho ma " + code + " duoi muc toi thieu, bo qua.");
            }
            return;
        }

        // Ghi nhan truoc khi thuong de tranh thuong 2 lan
        o.status = PAID;
        o.paidAmount = m.amount();
        o.txId = m.txId();
        paidTx.add(m.txId());
        saveOrders();

        double rate = getConfig().getDouble("reward.money-rate", 1.0);
        Bonus bonus = bonusFor(o.uuid);
        long moneyAmount = Math.max(1, Math.round(m.amount() * rate * (1 + bonus.rate())));
        for (String command : getConfig().getStringList("reward.commands")) {
            String cmd = command
                    .replace("%player%", o.name)
                    .replace("%amount%", String.valueOf(m.amount()))
                    .replace("%money%", String.valueOf(moneyAmount))
                    .replace("%points%", String.valueOf(moneyAmount));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
        getLogger().info("Nap thanh cong: " + o.name + " " + m.amount() + "d (" + moneyAmount + " tien game), ma " + code + ", giao dich " + m.txId());

        Player pl = Bukkit.getPlayer(o.uuid);
        if (pl != null) {
            removeQrMaps(pl);
            tell(pl, "success", Map.of("amount", money(m.amount()), "money", money(moneyAmount)));
        }
        afterReward(o.uuid, o.name, m.amount(), moneyAmount, bonus, rate, pl);
        sendWebhook(o.name, m.amount());
    }

    private void sendWebhook(String player, long amount) {
        notifyAll(fill(raw("discord-text"), Map.of("player", player, "amount", money(amount))));
    }

    /**
     * Gui thong bao len Discord (webhook) va Telegram (bot) cung luc.
     * Noi nao de trong cau hinh thi bo qua noi do. Text dung **dam** kieu Discord,
     * voi Telegram se tu doi sang <b>dam</b>.
     */
    private void notifyAll(String text) {
        FileConfiguration c = getConfig();
        String discordUrl = c.getString("reward.discord-webhook-url", "");
        String tgToken = c.getString("reward.telegram.bot-token", "").trim();
        String tgChat = c.getString("reward.telegram.chat-id", "").trim();
        boolean tg = !tgToken.isBlank() && !tgChat.isBlank();
        if (discordUrl.isBlank() && !tg) return;

        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            if (!discordUrl.isBlank()) {
                String json = "{\"username\":\"Card2k\",\"content\":\"" + esc(text) + "\"}";
                postJson(discordUrl, json, "Discord");
            }
            if (tg) {
                String html = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                        .replaceAll("\\*\\*(.+?)\\*\\*", "<b>$1</b>");
                String json = "{\"chat_id\":\"" + esc(tgChat) + "\","
                        + "\"parse_mode\":\"HTML\",\"disable_web_page_preview\":true,"
                        + "\"text\":\"" + esc(html) + "\"}";
                postJson("https://api.telegram.org/bot" + tgToken + "/sendMessage", json, "Telegram");
            }
        });
    }

    // Chay tren thread async. Khong in URL ra log vi URL webhook / token bot la bi mat.
    private void postJson(String url, String json, String label) {
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            con.setRequestProperty("User-Agent", "Card2k");
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);
            con.setDoOutput(true);
            try (OutputStream os = con.getOutputStream()) {
                os.write(json.getBytes(StandardCharsets.UTF_8));
            }
            int rc = con.getResponseCode();
            if (rc >= 400) getLogger().warning("Gui thong bao " + label + " that bai, ma HTTP " + rc);
            con.disconnect();
        } catch (Exception e) {
            getLogger().warning("Gui thong bao " + label + " loi: " + e.getClass().getSimpleName());
        }
    }

    private String esc(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': break;
                default: sb.append(ch);
            }
        }
        return sb.toString();
    }

    // ================= NAP THE CAO (Card2K) =================

    private void loadCards() {
        cards.clear();
        if (!cardsFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(cardsFile);
        ConfigurationSection sec = y.getConfigurationSection("cards");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection c = sec.getConfigurationSection(id);
            if (c == null) continue;
            try {
                CardOrder o = new CardOrder();
                o.requestId = id;
                o.uuid = UUID.fromString(c.getString("uuid", ""));
                o.name = c.getString("name", "?");
                o.telco = c.getString("telco", "");
                o.declared = c.getLong("declared");
                o.serial = c.getString("serial", "");
                o.code = c.getString("code", "");
                o.created = c.getLong("created");
                o.status = c.getString("status", PENDING);
                o.value = c.getLong("value");
                o.received = c.getLong("received");
                o.wrong = c.getBoolean("wrong", false);
                o.credited = c.getLong("credited", 0);
                cards.put(id, o);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveCards() {
        YamlConfiguration y = new YamlConfiguration();
        for (CardOrder o : cards.values()) {
            String p = "cards." + o.requestId + ".";
            y.set(p + "uuid", o.uuid.toString());
            y.set(p + "name", o.name);
            y.set(p + "telco", o.telco);
            y.set(p + "declared", o.declared);
            y.set(p + "serial", o.serial);
            y.set(p + "code", o.code);
            y.set(p + "created", o.created);
            y.set(p + "status", o.status);
            y.set(p + "value", o.value);
            y.set(p + "received", o.received);
            if (o.wrong) y.set(p + "wrong", true); // danh dau the sai menh gia
            if (o.credited > 0) y.set(p + "credited", o.credited);
        }
        try {
            y.save(cardsFile);
        } catch (IOException e) {
            getLogger().warning("Khong luu duoc cards.yml: " + e.getMessage());
        }
    }

    private void handleNapThe(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(raw("player-only"));
            return;
        }
        if (!p.hasPermission("card2k.use")) { tell(p, "no-permission", null); return; }
        if (args.length >= 1 && (args[0].equalsIgnoreCase("huy") || args[0].equalsIgnoreCase("cancel"))) {
            if (prompts.remove(p.getUniqueId()) != null) tell(p, "card-prompt-cancelled", null);
            else tell(p, "no-pending", null);
            return;
        }
        if (!checkCard(p)) return;
        // /napthe  -> mo giao dien chon nha mang
        if (args.length == 0) {
            openTelcoGui(p);
            return;
        }
        // /napthe <nha mang>  -> mo giao dien chon menh gia
        if (args.length == 1) {
            String t = args[0].toUpperCase(Locale.ROOT);
            if (!cardTelcos().contains(t)) {
                tell(p, "card-bad-telco", Map.of("telcos", String.join(", ", cardTelcos())));
                return;
            }
            openCardAmountGui(p, t);
            return;
        }
        // /napthe <nha mang> <menh gia>  -> nhap thang
        startCardPrompt(p, args[0].toUpperCase(Locale.ROOT), parseAmount(args[1]));
    }

    private List<String> cardTelcos() {
        ConfigurationSection sec = getConfig().getConfigurationSection("card.telcos");
        if (sec != null) { // dang map: TEN: true/false
            List<String> out = new ArrayList<>();
            for (String k : sec.getKeys(false)) if (sec.getBoolean(k, false)) out.add(k.toUpperCase(Locale.ROOT));
            return out;
        }
        return getConfig().getStringList("card.telcos").stream() // dang list cu
                .map(x -> x.toUpperCase(Locale.ROOT)).collect(Collectors.toList());
    }

    /** Mệnh giá cho từng nhà mạng: ưu tiên card.amounts-by-telco.<NHA MANG>, không có thì dùng card.amounts chung. */
    private List<Long> cardAmounts(String telco) {
        FileConfiguration c = getConfig();
        ConfigurationSection sec = c.getConfigurationSection("card.amounts-by-telco");
        if (sec != null && telco != null) {
            for (String k : sec.getKeys(false)) {
                if (k.equalsIgnoreCase(telco)) {
                    List<Long> l = sec.getLongList(k);
                    if (!l.isEmpty()) return l;
                }
            }
        }
        return c.getLongList("card.amounts");
    }

    private String fmtSeconds(long secs) {
        long m = secs / 60, s = secs % 60;
        if (m <= 0) return s + " giây";
        return s == 0 ? m + " phút" : m + " phút " + s + " giây";
    }

    /** Dang bi khoa nap the? Neu co thi bao cho nguoi choi va tra ve true. */
    private boolean cardLocked(Player p) {
        Long until = cardLockUntil.get(p.getUniqueId());
        if (until == null) return false;
        long left = until - System.currentTimeMillis();
        if (left <= 0) {
            cardLockUntil.remove(p.getUniqueId());
            return false;
        }
        tell(p, "card-locked", Map.of("time", fmtSeconds((left + 999) / 1000)));
        return true;
    }

    /** Ghi 1 lan nhap sai the, tra ve so giay bi khoa (0 = khong khoa). */
    private long strikeCard(UUID id) {
        FileConfiguration c = getConfig();
        if (!c.getBoolean("card.anti-spam.enabled", true)) return 0;
        long now = System.currentTimeMillis();
        long resetMs = c.getLong("card.anti-spam.reset-minutes", 60) * 60000L;
        Long last = cardLastFail.get(id);
        int n = (last != null && now - last <= resetMs) ? cardStrikes.getOrDefault(id, 0) : 0;
        n++;
        cardStrikes.put(id, n);
        cardLastFail.put(id, now);
        List<Long> steps = c.getLongList("card.anti-spam.lock-seconds");
        if (steps.isEmpty()) steps = List.of(0L, 300L, 3600L, 10800L, 86400L);
        long secs = steps.get(Math.min(n, steps.size()) - 1);
        if (secs > 0) cardLockUntil.put(id, now + secs * 1000L);
        return secs;
    }

    private void clearCardStrikes(UUID id) {
        cardStrikes.remove(id);
        cardLastFail.remove(id);
        cardLockUntil.remove(id);
    }

    /** Kiem tra hop le roi bat dau buoc nhap serial / ma the qua chat. */
    private void startCardPrompt(Player p, String telco, long amount) {
        FileConfiguration c = getConfig();
        if (!checkCard(p)) return;
        if (cardLocked(p)) return;
        String telcoText = String.join(", ", cardTelcos());
        String amountText = cardAmounts(telco).stream().map(this::money).collect(Collectors.joining(", "));
        if (!cardTelcos().contains(telco)) {
            tell(p, "card-bad-telco", Map.of("telcos", telcoText));
            return;
        }
        if (!cardAmounts(telco).contains(amount)) {
            tell(p, "card-bad-amount", Map.of("amounts", amountText));
            return;
        }
        int max = c.getInt("card.max-pending-per-player", 3);
        int count = 0;
        for (CardOrder o : cards.values()) if (PENDING.equals(o.status) && o.uuid.equals(p.getUniqueId())) count++;
        if (count >= max) {
            tell(p, "card-too-many", Map.of("max", String.valueOf(max)));
            return;
        }

        CardPrompt pr = new CardPrompt();
        pr.telco = telco;
        pr.amount = amount;
        prompts.put(p.getUniqueId(), pr);
        tell(p, "card-prompt-serial", Map.of("telco", telco, "amount", money(amount),
                "seconds", String.valueOf(c.getInt("card.prompt-seconds", 60))));
        showPromptTitle(p, "card-title-serial");
    }

    private void showPromptTitle(Player p, String titleKey) {
        if (!getConfig().getBoolean("gui.title-prompts", true)) return;
        LegacyComponentSerializer ser = LegacyComponentSerializer.legacyAmpersand();
        p.showTitle(Title.title(ser.deserialize(raw(titleKey)), ser.deserialize(raw("prompt-subtitle")),
                Title.Times.times(Duration.ofMillis(150), Duration.ofSeconds(5), Duration.ofMillis(400))));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (prompts.containsKey(id)) {
            // Chan tin nhan de nguoi khac va log khong thay so serial / ma the
            e.setCancelled(true);
            String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
            Bukkit.getScheduler().runTask(this, () -> handlePrompt(p, text));
            return;
        }
        Long since = amountPrompts.get(id);
        if (since != null) {
            long promptMs = getConfig().getLong("card.prompt-seconds", 60) * 1000L;
            if (System.currentTimeMillis() - since > promptMs) {
                amountPrompts.remove(id);
                return; // het han: de tin nhan di nhu chat binh thuong
            }
            e.setCancelled(true);
            String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
            Bukkit.getScheduler().runTask(this, () -> handleAmountPrompt(p, text));
        }
    }

    private void handleAmountPrompt(Player p, String text) {
        if (amountPrompts.remove(p.getUniqueId()) == null) return;
        if (text.equalsIgnoreCase("huy") || text.equalsIgnoreCase("cancel")) {
            tell(p, "gui-custom-cancelled", null);
            return;
        }
        createOrder(p, text);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        prompts.remove(e.getPlayer().getUniqueId());
        amountPrompts.remove(e.getPlayer().getUniqueId());
    }

    private void handlePrompt(Player p, String text) {
        CardPrompt pr = prompts.get(p.getUniqueId());
        if (pr == null) return;
        long promptMs = getConfig().getLong("card.prompt-seconds", 60) * 1000L;
        if (System.currentTimeMillis() - pr.created > promptMs) {
            prompts.remove(p.getUniqueId());
            tell(p, "card-prompt-expired", null);
            return;
        }
        if (text.equalsIgnoreCase("huy") || text.equalsIgnoreCase("cancel")) {
            prompts.remove(p.getUniqueId());
            tell(p, "card-prompt-cancelled", null);
            return;
        }
        if (!text.matches("[A-Za-z0-9]{6,32}")) {
            tell(p, "card-invalid-input", null);
            return;
        }
        if (!pr.needCode) {
            pr.serial = text;
            pr.needCode = true;
            pr.created = System.currentTimeMillis();
            tell(p, "card-prompt-code", null);
            showPromptTitle(p, "card-title-code");
            return;
        }
        prompts.remove(p.getUniqueId());
        submitCard(p, pr, text);
    }

    private String newRequestId() {
        while (true) {
            StringBuilder sb = new StringBuilder("CC");
            for (int i = 0; i < 12; i++) sb.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
            if (!cards.containsKey(sb.toString())) return sb.toString();
        }
    }

    private void submitCard(Player p, CardPrompt pr, String code) {
        if (cardLocked(p)) return;
        CardOrder co = new CardOrder();
        co.requestId = newRequestId();
        co.uuid = p.getUniqueId();
        co.name = p.getName();
        co.telco = pr.telco;
        co.declared = pr.amount;
        co.serial = pr.serial;
        co.code = code;
        co.created = System.currentTimeMillis();
        co.sent = false;
        // Luu truoc khi gui de khong bi mat dau vet neu server tat giua chung
        cards.put(co.requestId, co);
        saveCards();

        tell(p, "card-submitting", Map.of("telco", co.telco, "amount", money(co.declared)));
        final CardSnap snap = new CardSnap(co.requestId, co.telco, co.declared, co.serial, co.code);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            JsonObject r = null;
            try {
                r = cardCall("charging", snap);
            } catch (Exception e) {
                getLogger().warning("Loi gui the " + snap.requestId() + " (" + e.getClass().getSimpleName() + ")");
            }
            final JsonObject fr = r;
            Bukkit.getScheduler().runTask(this, () -> {
                CardOrder cur = cards.get(snap.requestId());
                if (cur != null) cur.sent = true;
                handleCardResult(snap.requestId(), fr, true);
            });
        });
    }

    private String md5(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest(s.getBytes(StandardCharsets.UTF_8))) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    /** Goi API Card2K (mục 1): command la "charging" (gui the) hoac "check" (tra the). */
    private JsonObject cardCall(String command, CardSnap s) throws IOException {
        FileConfiguration c = getConfig();
        String key = c.getString("card.partner-key", "");
        String body = "command=" + enc(command)
                + "&telco=" + enc(s.telco())
                + "&code=" + enc(s.code())
                + "&serial=" + enc(s.serial())
                + "&amount=" + s.declared()
                + "&request_id=" + enc(s.requestId())
                + "&partner_id=" + enc(c.getString("card.partner-id", ""))
                + "&sign=" + md5(key + s.code() + s.serial());

        HttpURLConnection con = (HttpURLConnection) new URL(CARD_API_URL).openConnection();
        try {
            con.setRequestMethod("POST");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            con.setRequestProperty("User-Agent", "Card2k");
            con.setConnectTimeout(10000);
            con.setReadTimeout(15000);
            con.setDoOutput(true);
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int rc = con.getResponseCode();
            if (rc == 429 || rc >= 500) {
                getLogger().warning("Card2K tra ve ma " + rc + ", se thu lai sau.");
                return null;
            }
            InputStream in = rc >= 400 ? con.getErrorStream() : con.getInputStream();
            if (in == null) return null;
            String text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            JsonElement el = JsonParser.parseString(text);
            return el.isJsonObject() ? el.getAsJsonObject() : null;
        } finally {
            con.disconnect();
        }
    }

    private int intOf(JsonObject o, String key, int def) {
        JsonElement e = o.get(key);
        if (e == null || e.isJsonNull() || !e.isJsonPrimitive()) return def;
        try {
            return (int) Double.parseDouble(e.getAsString());
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    private void cardTick() {
        long promptMs = getConfig().getLong("card.prompt-seconds", 60) * 1000L;
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, CardPrompt> en : new ArrayList<>(prompts.entrySet())) {
            if (now - en.getValue().created > promptMs && prompts.remove(en.getKey(), en.getValue())) {
                Player pl = Bukkit.getPlayer(en.getKey());
                if (pl != null) tell(pl, "card-prompt-expired", null);
            }
        }
        if (cardPolling.get()) return;
        if (getConfig().getString("card.partner-id", "").isBlank()) return;

        List<CardSnap> snaps = new ArrayList<>();
        for (CardOrder o : cards.values()) {
            if (PENDING.equals(o.status) && o.sent && !o.code.isEmpty()) {
                snaps.add(new CardSnap(o.requestId, o.telco, o.declared, o.serial, o.code));
            }
        }
        if (snaps.isEmpty()) return;

        cardPolling.set(true);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            Map<String, JsonObject> results = new LinkedHashMap<>();
            try {
                for (CardSnap sn : snaps) {
                    try {
                        JsonObject r = cardCall("check", sn);
                        if (r != null) results.put(sn.requestId(), r);
                    } catch (IOException e) {
                        getLogger().warning("Loi tra the " + sn.requestId() + " (" + e.getClass().getSimpleName() + ")");
                    }
                    Thread.sleep(400);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            Bukkit.getScheduler().runTask(this, () -> {
                try {
                    for (Map.Entry<String, JsonObject> en : results.entrySet()) {
                        handleCardResult(en.getKey(), en.getValue(), false);
                    }
                } finally {
                    cardPolling.set(false);
                }
            });
        });
    }

    // Chay tren main thread
    private void handleCardResult(String id, JsonObject r, boolean fromSubmit) {
        CardOrder co = cards.get(id);
        if (co == null || !PENDING.equals(co.status)) return;
        Player pl = Bukkit.getPlayer(co.uuid);
        if (r == null) {
            if (fromSubmit && pl != null) tell(pl, "card-network", null);
            return; // giu o trang thai cho, lan tra the sau se quyet dinh
        }
        int st = intOf(r, "status", -1);
        String msg = str(r, "message");
        switch (st) {
            case 99:
                if (fromSubmit && pl != null) tell(pl, "card-received", null);
                return;
            case 4:
                if (fromSubmit) failCard(co, "Hệ thống thẻ đang bảo trì, hãy thử lại sau");
                return;
            case 1:
                finishCard(co, true, intOf(r, "value", 0), intOf(r, "amount", 0));
                return;
            case 2:
                finishCard(co, false, intOf(r, "value", 0), intOf(r, "amount", 0));
                return;
            default:
                failCard(co, msg.isBlank() ? "Thẻ không hợp lệ" : msg, true);
        }
    }

    private void failCard(CardOrder co, String reason) {
        failCard(co, reason, false);
    }

    private void failCard(CardOrder co, String reason, boolean strike) {
        co.status = FAILED;
        co.serial = "";
        co.code = "";
        saveCards();
        getLogger().info("The loi: " + co.name + " " + co.telco + " " + co.declared + "d, ma " + co.requestId);
        Player pl = Bukkit.getPlayer(co.uuid);
        if (pl != null) tell(pl, "card-failed", Map.of("reason", reason));
        if (strike) {
            long secs = strikeCard(co.uuid);
            if (pl != null) {
                if (secs > 0) tell(pl, "card-lock-notice", Map.of("time", fmtSeconds(secs)));
                else if (getConfig().getBoolean("card.anti-spam.enabled", true)) tell(pl, "card-lock-warning", null);
            }
        }
    }

    private void finishCard(CardOrder co, boolean exact, long value, long received) {
        FileConfiguration c = getConfig();
        long base;
        if (exact) {
            base = value > 0 ? value : co.declared;
        } else if ("received".equalsIgnoreCase(c.getString("card.wrong-amount-reward", "received"))) {
            // Sai mệnh giá: trừ thêm wrong-amount-penalty (mặc định 50%) trên số tiền được tính
            double penalty = Math.min(1.0, Math.max(0.0, c.getDouble("card.wrong-amount-penalty", 0.5)));
            base = Math.round(received * (1.0 - penalty));
        } else {
            base = 0;
        }
        if (base <= 0) {
            failCard(co, "Thẻ sai mệnh giá nên không được cộng tiền", true);
            return;
        }

        clearCardStrikes(co.uuid);
        // Ghi nhan truoc khi thuong de tranh thuong 2 lan; xoa so serial/ma the khoi file
        co.status = DONE;
        co.value = value;
        co.received = received;
        co.wrong = !exact;
        co.credited = base;
        co.serial = "";
        co.code = "";
        saveCards();

        long penaltyPercent = exact ? 0
                : Math.round(Math.min(1.0, Math.max(0.0, c.getDouble("card.wrong-amount-penalty", 0.5))) * 100);
        final double cardRate = c.getDouble("card.money-rate", 1.0);
        Bonus bonus = bonusFor(co.uuid);
        long moneyAmount = Math.max(1, Math.round(base * cardRate * (1 + bonus.rate())));
        for (String command : c.getStringList("card.commands")) {
            String cmd = command
                    .replace("%player%", co.name)
                    .replace("%amount%", String.valueOf(base))
                    .replace("%declared%", String.valueOf(co.declared))
                    .replace("%money%", String.valueOf(moneyAmount))
                    .replace("%points%", String.valueOf(moneyAmount));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
        getLogger().info("Nap the thanh cong: " + co.name + " " + co.telco
                + (exact ? " menh gia " + co.declared + "d"
                        : " SAI MENH GIA (khai " + co.declared + "d, that " + value + "d, tru phat " + penaltyPercent + "%)")
                + ", tinh " + base + "d (" + moneyAmount + " tien game), ma " + co.requestId);

        Player pl = Bukkit.getPlayer(co.uuid);
        if (pl != null) {
            String key = exact ? "card-success" : "card-wrong-amount";
            tell(pl, key, Map.of("amount", money(base), "money", money(moneyAmount), "declared", money(co.declared),
                    "penalty", String.valueOf(penaltyPercent)));
        }
        afterReward(co.uuid, co.name, base, moneyAmount, bonus, cardRate, pl);
        if (exact) sendCardWebhook(co.name, base);
        else sendCardWrongWebhook(co, base, value, penaltyPercent);
    }

    private void sendCardWebhook(String player, long amount) {
        notifyAll(fill(raw("discord-card-text"), Map.of("player", player, "amount", money(amount))));
    }

    private void sendCardWrongWebhook(CardOrder co, long base, long value, long penaltyPercent) {
        notifyAll(fill(raw("discord-card-wrong-text"), Map.of(
                "player", co.name,
                "telco", co.telco,
                "declared", money(co.declared),
                "value", value > 0 ? money(value) : "?",
                "penalty", String.valueOf(penaltyPercent),
                "amount", money(base))));
    }

    // ================= KIEM TRA PHIEN BAN =================

    private static final String UPDATE_API = "https://card2k.net/api/minecraft/v1/version?current=";

    private record UpdateInfo(String status, String level, boolean required, String message,
                              String latest, String download, String changelog) {
        boolean hasUpdate() {
            return ("update_available".equals(status) || "update_required".equals(status))
                    && message != null && !message.isBlank();
        }

        boolean urgent() {
            return required || "critical".equals(level) || "update_required".equals(status);
        }
    }

    private volatile UpdateInfo updateInfo;
    private final Set<UUID> updateNotified = ConcurrentHashMap.newKeySet();
    private String lastUpdateSig = "";
    private int updateTaskId = -1;

    private void startUpdateCheck() {
        if (updateTaskId != -1) Bukkit.getScheduler().cancelTask(updateTaskId);
        updateTaskId = -1;
        if (!getConfig().getBoolean("update-check.enabled", true)) return;
        long hours = Math.min(24, Math.max(6, getConfig().getLong("update-check.interval-hours", 6)));
        updateTaskId = Bukkit.getScheduler().runTaskTimerAsynchronously(this,
                () -> runUpdateCheck(null), 20L * 30, hours * 3600L * 20L).getTaskId();
    }

    /** Chay tren thread async. Moi loi deu bo qua lang le, khong lam anh huong server. */
    private void runUpdateCheck(CommandSender manual) {
        UpdateInfo u = fetchUpdate();
        Bukkit.getScheduler().runTask(this, () -> handleUpdate(u, manual));
    }

    private UpdateInfo fetchUpdate() {
        try {
            String ver = getPluginMeta().getVersion();
            HttpURLConnection con = (HttpURLConnection) new URL(UPDATE_API + URLEncoder.encode(ver, StandardCharsets.UTF_8)).openConnection();
            try {
                con.setRequestMethod("GET");
                con.setRequestProperty("Accept", "application/json");
                con.setRequestProperty("User-Agent", "Card2k/" + ver);
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                int rc = con.getResponseCode();
                if (rc != 200) {
                    getLogger().fine("Kiem tra cap nhat: HTTP " + rc);
                    return null;
                }
                JsonElement el = JsonParser.parseString(new String(con.getInputStream().readAllBytes(), StandardCharsets.UTF_8));
                if (!el.isJsonObject()) return null;
                JsonObject o = el.getAsJsonObject();
                JsonObject up = o.get("update") != null && o.get("update").isJsonObject() ? o.getAsJsonObject("update") : null;
                JsonObject latest = o.get("latest") != null && o.get("latest").isJsonObject() ? o.getAsJsonObject("latest") : null;
                boolean required = up != null && up.get("required") != null && up.get("required").isJsonPrimitive()
                        && up.get("required").getAsBoolean();
                return new UpdateInfo(
                        str(o, "status"),
                        up == null ? "" : str(up, "level"),
                        required,
                        up == null ? "" : str(up, "message"),
                        latest == null ? "" : str(latest, "version"),
                        latest == null ? "" : str(latest, "download_url"),
                        latest == null ? "" : str(latest, "changelog_url"));
            } finally {
                con.disconnect();
            }
        } catch (Exception e) {
            getLogger().fine("Kiem tra cap nhat loi: " + e.getClass().getSimpleName());
            return null;
        }
    }

    private NamedTextColor updateColor(UpdateInfo u) {
        if (u.urgent()) return NamedTextColor.RED;
        if ("important".equals(u.level)) return NamedTextColor.YELLOW;
        return NamedTextColor.GREEN;
    }

    private void sendUpdate(CommandSender to, UpdateInfo u) {
        NamedTextColor col = updateColor(u);
        to.sendMessage(Component.text("[Card2k] ", NamedTextColor.GOLD).append(Component.text(u.message(), col)));
        String link = !u.download().isBlank() ? u.download() : u.changelog();
        if (link.startsWith("https://")) {
            to.sendMessage(Component.text("» Tải bản " + u.latest() + ": " + link, NamedTextColor.AQUA, TextDecoration.UNDERLINED)
                    .clickEvent(ClickEvent.openUrl(link)));
        }
    }

    // Chay tren main thread
    private void handleUpdate(UpdateInfo u, CommandSender manual) {
        if (u == null) {
            if (manual != null) manual.sendMessage(color("&e⚠ Không kiểm tra được bản mới (thử lại sau)."));
            return;
        }
        updateInfo = u;
        if (!u.hasUpdate()) {
            if (manual != null) {
                manual.sendMessage(color("up_to_date".equals(u.status())
                        ? "&a✔ Bạn đang dùng bản mới nhất."
                        : "&7Chưa có thông tin bản mới cho phiên bản đang chạy."));
            }
            return;
        }
        String sig = u.latest() + ":" + u.level() + ":" + u.required();
        boolean changed = !sig.equals(lastUpdateSig);
        lastUpdateSig = sig;
        if (u.urgent() || changed || manual != null) sendUpdate(Bukkit.getConsoleSender(), u);
        if (manual != null) sendUpdate(manual, u);
        // Co ban moi lan dau thay: bao luon cho admin dang online (tru muc "nho")
        if (changed && !"minor".equals(u.level())) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.hasPermission("card2k.update.notify")) continue;
                if (!u.urgent()) updateNotified.add(p.getUniqueId());
                sendUpdate(p, u);
            }
        }
    }

    private void notifyUpdateOnJoin(Player p) {
        UpdateInfo u = updateInfo;
        if (u == null || !u.hasUpdate() || "minor".equals(u.level())) return;
        if (!p.hasPermission("card2k.update.notify")) return;
        if (!u.urgent() && !updateNotified.add(p.getUniqueId())) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) sendUpdate(p, u);
        }, 40L);
    }

    // ================= KHUYEN MAI + MOC NAP =================

    private static final List<String> PERIODS = List.of("all", "day", "week", "month", "year");
    private static final java.time.format.DateTimeFormatter TIME_FMT =
            java.time.format.DateTimeFormatter.ofPattern("dd/MM/uuuu HH:mm[:ss]")
                    .withResolverStyle(java.time.format.ResolverStyle.STRICT);

    private static class Promo {
        String name;
        double rate;
        java.time.LocalDateTime from, to;
        Set<java.time.DayOfWeek> days;   // null = moi ngay
        List<int[]> hours;               // phut [bat dau, ket thuc), null = ca ngay
        boolean weekly;
    }

    private static class Milestone {
        String type;
        long amount;
        List<String> commands = new ArrayList<>();
    }

    private static class Bonus {
        String name = "";
        double promoRate;
        boolean first;
        double firstRate;

        double rate() {
            return promoRate + (first ? firstRate : 0);
        }
    }

    private final List<Promo> promos = new ArrayList<>();
    private final List<Milestone> milestones = new ArrayList<>();
    private String legacyName = "&aKhuyến mãi";
    private boolean firstEnabled = false;
    private double firstRate = 1.0;
    private List<String> firstCommands = new ArrayList<>();
    private boolean warnedLegacy = false;
    private File promoFile, milestoneFile, donorsFile;
    private YamlConfiguration donors = new YamlConfiguration();

    private void initPromoFiles() {
        promoFile = new File(getDataFolder(), "khuyenmai.yml");
        milestoneFile = new File(getDataFolder(), "mocnap.yml");
        donorsFile = new File(getDataFolder(), "donors.yml");
        if (!promoFile.exists()) saveResource("khuyenmai.yml", false);
        if (!milestoneFile.exists()) saveResource("mocnap.yml", false);
        loadPromoConfig();
        boolean fresh = !donorsFile.exists();
        donors = fresh ? new YamlConfiguration() : YamlConfiguration.loadConfiguration(donorsFile);
        if (fresh) importHistory();
    }

    private String rawd(String key, String def) {
        return getConfig().getString("messages." + key, def);
    }

    private void loadPromoConfig() {
        promos.clear();
        milestones.clear();
        warnedLegacy = false;

        YamlConfiguration y = YamlConfiguration.loadConfiguration(promoFile);
        legacyName = y.getString("legacy-name", "&aKhuyến mãi");
        firstEnabled = y.getBoolean("first-donate.enabled", false);
        firstRate = Math.max(0, y.getDouble("first-donate.extra-rate", 1.0));
        firstCommands = new ArrayList<>(y.getStringList("first-donate.commands"));

        List<Map<?, ?>> list = y.getMapList("khuyen-mai");
        for (int i = 0; i < list.size(); i++) {
            try {
                promos.add(parsePromo(list.get(i)));
            } catch (IllegalArgumentException e) {
                getLogger().warning("khuyenmai.yml: muc #" + (i + 1) + " khong hop le (" + e.getMessage() + "), bo qua.");
            }
        }

        YamlConfiguration m = YamlConfiguration.loadConfiguration(milestoneFile);
        List<Map<?, ?>> ml = m.getMapList("mocnap");
        for (int i = 0; i < ml.size(); i++) {
            Map<?, ?> e = ml.get(i);
            try {
                Milestone ms = new Milestone();
                ms.type = String.valueOf(e.get("type")).trim().toLowerCase(Locale.ROOT);
                if (!PERIODS.contains(ms.type)) throw new IllegalArgumentException("type phai la " + PERIODS);
                Object a = e.get("amount");
                ms.amount = a == null ? 0 : Math.round(Double.parseDouble(String.valueOf(a).trim()));
                if (ms.amount <= 0) throw new IllegalArgumentException("amount phai > 0");
                Object cmds = e.get("commands");
                if (cmds instanceof List<?> cl) for (Object o : cl) ms.commands.add(String.valueOf(o));
                else if (cmds != null) ms.commands.add(String.valueOf(cmds));
                milestones.add(ms);
            } catch (IllegalArgumentException ex) {
                getLogger().warning("mocnap.yml: muc #" + (i + 1) + " khong hop le (" + ex.getMessage() + "), bo qua.");
            }
        }
        getLogger().info("Khuyen mai: " + promos.size() + " lich, moc nap: " + milestones.size() + " moc.");
    }

    private static java.time.LocalDateTime parseTime(Object v, String what) {
        if (v == null || String.valueOf(v).isBlank()) throw new IllegalArgumentException(what + " de trong");
        try {
            return java.time.LocalDateTime.parse(String.valueOf(v).trim(), TIME_FMT);
        } catch (java.time.format.DateTimeParseException e) {
            throw new IllegalArgumentException(what + " sai dinh dang dd/MM/yyyy HH:mm[:ss]");
        }
    }

    private static Set<java.time.DayOfWeek> parseDays(Object v) {
        List<String> parts = new ArrayList<>();
        if (v instanceof List<?> l) for (Object o : l) parts.add(String.valueOf(o));
        else parts.addAll(List.of(String.valueOf(v).split(",")));
        Set<java.time.DayOfWeek> out = new HashSet<>();
        for (String p : parts) {
            int n;
            try {
                n = Integer.parseInt(p.trim());
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("days sai");
            }
            if (n < 2 || n > 8) throw new IllegalArgumentException("days chi nhan 2-8 (8 = chu nhat)");
            out.add(n == 8 ? java.time.DayOfWeek.SUNDAY : java.time.DayOfWeek.of(n - 1));
        }
        if (out.isEmpty()) throw new IllegalArgumentException("days de trong");
        return out;
    }

    private static int minutesOf(String hhmm) {
        String[] p = hhmm.trim().split(":");
        if (p.length != 2) throw new IllegalArgumentException("hours sai");
        int h, m;
        try {
            h = Integer.parseInt(p[0].trim());
            m = Integer.parseInt(p[1].trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("hours sai");
        }
        if (m < 0 || m > 59 || h < 0 || h > 24 || (h == 24 && m != 0)) throw new IllegalArgumentException("hours ngoai khoang 00:00-24:00");
        return h * 60 + m;
    }

    private static List<int[]> parseHours(Object v) {
        List<String> parts = new ArrayList<>();
        if (v instanceof List<?> l) for (Object o : l) parts.add(String.valueOf(o));
        else parts.add(String.valueOf(v));
        List<int[]> out = new ArrayList<>();
        for (String p : parts) {
            String[] se = p.split("-");
            if (se.length != 2) throw new IllegalArgumentException("hours phai dang 'HH:mm-HH:mm'");
            int s = minutesOf(se[0]);
            int e = minutesOf(se[1]);
            if (e <= s) throw new IllegalArgumentException("gio ket thuc phai sau gio bat dau");
            out.add(new int[]{s, e});
        }
        if (out.isEmpty()) throw new IllegalArgumentException("hours de trong");
        return out;
    }

    private Promo parsePromo(Map<?, ?> e) {
        Promo p = new Promo();
        Object n = e.get("name");
        p.name = n == null ? "Khuyến mãi" : String.valueOf(n);
        Object r = e.get("rate");
        if (r == null) throw new IllegalArgumentException("thieu rate");
        try {
            p.rate = Double.parseDouble(String.valueOf(r).trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("rate khong phai so");
        }
        if (p.rate < 0) throw new IllegalArgumentException("rate < 0");
        boolean hasFrom = e.containsKey("from"), hasTo = e.containsKey("to");
        boolean hasDays = e.containsKey("days"), hasHours = e.containsKey("hours");
        if (hasFrom) p.from = parseTime(e.get("from"), "from");
        if (hasTo) p.to = parseTime(e.get("to"), "to");
        if (hasDays) p.days = parseDays(e.get("days"));
        if (hasHours) p.hours = parseHours(e.get("hours"));
        p.weekly = hasDays || hasHours;
        if (!p.weekly && !(hasFrom && hasTo)) throw new IllegalArgumentException("can from+to, hoac days/hours");
        if (p.from != null && p.to != null && !p.from.isBefore(p.to)) throw new IllegalArgumentException("from phai truoc to");
        return p;
    }

    private boolean promoActive(Promo p, java.time.LocalDateTime now) {
        if (p.from != null && now.isBefore(p.from)) return false;
        if (p.to != null && !now.isBefore(p.to)) return false;
        if (!p.weekly) return true;
        if (p.days != null && !p.days.contains(now.getDayOfWeek())) return false;
        if (p.hours != null) {
            int m = now.getHour() * 60 + now.getMinute();
            boolean in = false;
            for (int[] h : p.hours) if (m >= h[0] && m < h[1]) { in = true; break; }
            if (!in) return false;
        }
        return true;
    }

    /** Khuyen mai dang ap dung: rate cao nhat trong khuyenmai.yml; khong co thi dung extra-rate trong config.yml. */
    private Promo currentPromo() {
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        Promo best = null;
        for (Promo p : promos) {
            if (promoActive(p, now) && (best == null || p.rate > best.rate)) best = p;
        }
        if (best != null) return best;
        double er = getConfig().getDouble("extra-rate", 0);
        if (er <= 0) return null;
        String until = getConfig().getString("extra-until", "");
        try {
            java.time.LocalDateTime end = parseTime(until, "extra-until");
            if (!now.isBefore(end)) return null;
            Promo p = new Promo();
            p.name = legacyName;
            p.rate = er;
            p.to = end;
            return p;
        } catch (IllegalArgumentException ex) {
            if (!warnedLegacy) {
                warnedLegacy = true;
                getLogger().warning("config.yml: extra-until khong hop le, coi nhu khuyen mai da het han.");
            }
            return null;
        }
    }

    private long donorCount(UUID id) {
        return donors.getLong("players." + id + ".count", 0);
    }

    private Bonus bonusFor(UUID id) {
        Bonus b = new Bonus();
        Promo p = currentPromo();
        if (p != null) {
            b.name = p.name;
            b.promoRate = p.rate;
        }
        if (firstEnabled && donorCount(id) == 0) {
            b.first = true;
            b.firstRate = firstRate;
        }
        return b;
    }

    /** So tien game nguoi choi se nhan khi nap `amount` (de hien thi tren GUI). */
    private long previewGain(Player p, long amount, double moneyRate) {
        Bonus b = bonusFor(p.getUniqueId());
        return Math.max(1, Math.round(amount * moneyRate * (1 + b.rate())));
    }

    private String bonusTag(Player p) {
        Bonus b = bonusFor(p.getUniqueId());
        if (b.rate() <= 0) return "";
        return " &6(+" + Math.round(b.rate() * 100) + "% KM)";
    }

    private String periodKey(String type, java.time.LocalDateTime t) {
        switch (type) {
            case "day": return t.toLocalDate().toString();
            case "week": return t.get(java.time.temporal.IsoFields.WEEK_BASED_YEAR) + "-W" + t.get(java.time.temporal.IsoFields.WEEK_OF_WEEK_BASED_YEAR);
            case "month": return java.time.YearMonth.from(t).toString();
            case "year": return String.valueOf(t.getYear());
            default: return "all";
        }
    }

    private void saveDonors() {
        try {
            donors.save(donorsFile);
        } catch (IOException e) {
            getLogger().warning("Khong luu duoc donors.yml: " + e.getMessage());
        }
    }

    /** Cong don 1 lan nap vao thong ke; tra ve danh sach moc vua dat (chua chay lenh). */
    private List<Runnable> recordDonation(UUID id, String name, long base, java.time.LocalDateTime now, boolean fire) {
        List<Runnable> out = new ArrayList<>();
        String root = "players." + id;
        donors.set(root + ".name", name);
        donors.set(root + ".count", donors.getLong(root + ".count", 0) + 1);
        donors.set(root + ".total", donors.getLong(root + ".total", 0) + base);
        for (String type : PERIODS) {
            String key = periodKey(type, now);
            String pp = root + ".periods." + type;
            long before;
            List<Long> claimed;
            if (!key.equals(donors.getString(pp + ".key"))) {
                before = 0;
                claimed = new ArrayList<>();
                donors.set(pp + ".key", key);
            } else {
                before = donors.getLong(pp + ".total", 0);
                claimed = new ArrayList<>(donors.getLongList(pp + ".claimed"));
            }
            long after = before + base;
            if (fire) {
                for (Milestone m : milestones) {
                    if (!m.type.equals(type) || claimed.contains(m.amount)) continue;
                    if (before < m.amount && after >= m.amount) {
                        claimed.add(m.amount);
                        final long total = after;
                        out.add(() -> runCommands(m.commands, Map.of(
                                "player", name, "amount", String.valueOf(m.amount),
                                "total", String.valueOf(total), "type", m.type)));
                        getLogger().info("Dat moc nap " + m.type + " " + m.amount + "d: " + name);
                    }
                }
            }
            donors.set(pp + ".total", after);
            donors.set(pp + ".claimed", claimed);
        }
        return out;
    }

    private void runCommands(List<String> cmds, Map<String, String> ph) {
        for (String c : cmds) {
            String x = c;
            for (Map.Entry<String, String> en : ph.entrySet()) {
                x = x.replace("%" + en.getKey() + "%", en.getValue())
                        .replace("%" + en.getKey().toUpperCase(Locale.ROOT) + "%", en.getValue());
            }
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), x);
        }
    }

    /** Lan chay dau (chua co donors.yml): gom lich su tu orders.yml / cards.yml, khong tra thuong moc. */
    private void importHistory() {
        int n = 0;
        for (Order o : orders.values()) {
            if (!PAID.equals(o.status) || o.paidAmount <= 0) continue;
            recordDonation(o.uuid, o.name, o.paidAmount, java.time.LocalDateTime.ofInstant(
                    java.time.Instant.ofEpochMilli(o.created), java.time.ZoneId.systemDefault()), false);
            n++;
        }
        for (CardOrder co : cards.values()) {
            if (!DONE.equals(co.status)) continue;
            long amt = co.credited > 0 ? co.credited : co.declared;
            if (amt <= 0) continue;
            recordDonation(co.uuid, co.name, amt, java.time.LocalDateTime.ofInstant(
                    java.time.Instant.ofEpochMilli(co.created), java.time.ZoneId.systemDefault()), false);
            n++;
        }
        if (n > 0) {
            saveDonors();
            getLogger().info("Da gom " + n + " lan nap cu vao donors.yml (dung cho nap lan dau va moc nap).");
        }
    }

    /** Goi sau khi da cong tien: thong bao khuyen mai, lenh nap lan dau, ghi thong ke, tra thuong moc. */
    private void afterReward(UUID id, String name, long base, long moneyAmount, Bonus b, double moneyRate, Player pl) {
        long plain = Math.max(1, Math.round(base * moneyRate));
        if (pl != null) {
            if (b.promoRate > 0) {
                pl.sendMessage(color(fill(rawd("promo-bonus", "&6🎁 Khuyến mãi {name}&6: &e+{percent}% &7(thêm {bonus} tiền game)"),
                        Map.of("name", b.name, "percent", String.valueOf(Math.round(b.promoRate * 100)),
                                "bonus", money(Math.round(base * moneyRate * b.promoRate))))));
            }
            if (b.first) {
                pl.sendMessage(color(fill(rawd("first-bonus", "&d🎉 Nạp lần đầu: &e+{percent}% &7(thêm {bonus} tiền game)"),
                        Map.of("percent", String.valueOf(Math.round(b.firstRate * 100)),
                                "bonus", money(Math.round(base * moneyRate * b.firstRate))))));
            }
        }
        List<Runnable> fire = recordDonation(id, name, base, java.time.LocalDateTime.now(), true);
        saveDonors();
        if (b.first && !firstCommands.isEmpty()) {
            runCommands(firstCommands, Map.of(
                    "player", name, "amount", String.valueOf(base), "point", String.valueOf(moneyAmount),
                    "point_unit", getConfig().getString("reward.point-unit", "tiền game"),
                    "extra_rate", String.valueOf(Math.round(b.firstRate * 100))));
        }
        for (Runnable r : fire) r.run();
        if (b.rate() > 0) {
            getLogger().info("Khuyen mai: " + name + " +" + Math.round(b.rate() * 100) + "% ("
                    + (b.promoRate > 0 ? b.name.replaceAll("&[0-9a-fk-or]", "") : "") + (b.first ? " + nap lan dau" : "") + "), "
                    + plain + " -> " + moneyAmount);
        }
    }

    private String describePromo(Promo p) {
        java.time.format.DateTimeFormatter f = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        StringBuilder sb = new StringBuilder();
        if (p.weekly) {
            if (p.days != null) {
                String[] names = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
                List<String> ds = new ArrayList<>();
                for (java.time.DayOfWeek d : java.time.DayOfWeek.values()) if (p.days.contains(d)) ds.add(names[d.getValue() - 1]);
                sb.append(String.join(", ", ds));
            } else {
                sb.append("Mọi ngày");
            }
            if (p.hours != null) {
                List<String> hs = new ArrayList<>();
                for (int[] h : p.hours) hs.add(String.format("%02d:%02d-%02d:%02d", h[0] / 60, h[0] % 60, h[1] / 60, h[1] % 60));
                sb.append(" • ").append(String.join(", ", hs));
            }
            if (p.from != null) sb.append(" • từ ").append(f.format(p.from));
            if (p.to != null) sb.append(" • đến ").append(f.format(p.to));
        } else {
            sb.append(f.format(p.from)).append(" → ").append(f.format(p.to));
        }
        return sb.toString();
    }

    private void showPromos(CommandSender to, String pageArg) {
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        Promo cur = currentPromo();
        List<Promo> active = new ArrayList<>(), upcoming = new ArrayList<>();
        for (Promo p : promos) {
            if (promoActive(p, now)) active.add(p);
            else if (p.to == null || now.isBefore(p.to)) upcoming.add(p);
        }
        List<Promo> all = new ArrayList<>(active);
        all.addAll(upcoming);
        if (cur != null && !promos.contains(cur)) all.add(0, cur);  // khuyen mai nhanh trong config.yml

        if (all.isEmpty() && !firstEnabled) {
            to.sendMessage(color(rawd("prefix", "") + rawd("promo-none", "&7Hiện chưa có khuyến mãi nào.")));
            return;
        }
        int per = 3;
        int pages = Math.max(1, (all.size() + per - 1) / per);
        int page = 1;
        try {
            if (pageArg != null) page = Integer.parseInt(pageArg);
        } catch (NumberFormatException ignored) {
        }
        page = Math.min(Math.max(1, page), pages);
        to.sendMessage(color("&8&m      &r &6☕ Khuyến mãi &7(" + page + "/" + pages + ") &8&m      "));
        for (int i = (page - 1) * per; i < Math.min(all.size(), page * per); i++) {
            Promo p = all.get(i);
            boolean on = (cur == p);
            boolean running = promoActive(p, now) || p == cur;
            to.sendMessage(color((on ? "&e★ " : "&7• ") + p.name + " &f+" + Math.round(p.rate * 100) + "%"
                    + (running ? " &a(đang diễn ra)" : " &7(sắp diễn ra)")));
            if (p.from != null || p.weekly) to.sendMessage(color("   &7" + (p.weekly || p.from != null ? describePromo(p) : "")));
            else if (p.to != null) to.sendMessage(color("   &7Đến " + p.to.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))));
        }
        if (firstEnabled && page == pages) {
            to.sendMessage(color("&d🎉 Nạp lần đầu: &f+" + Math.round(firstRate * 100) + "% &7(cộng thêm vào khuyến mãi đang áp dụng)"));
        }
        if (pages > 1) to.sendMessage(color("&7Xem trang khác: &f/khuyenmai <trang>"));
    }

    private void testPoint(CommandSender to, String arg) {
        long amount = arg == null ? -1 : parseAmount(arg);
        if (amount <= 0) {
            to.sendMessage(color("&eDùng: &f/card2k testpoint <số tiền>"));
            return;
        }
        Promo p = currentPromo();
        double promoRate = p == null ? 0 : p.rate;
        double bankRate = getConfig().getDouble("reward.money-rate", 1.0);
        double cardRate = getConfig().getDouble("card.money-rate", 1.0);
        to.sendMessage(color("&6Khuyến mãi đang áp dụng: " + (p == null ? "&7không có" : p.name + " &f+" + Math.round(p.rate * 100) + "%")));
        to.sendMessage(color("&7Bank " + money(amount) + "đ → &e" + money(Math.max(1, Math.round(amount * bankRate * (1 + promoRate)))) + " &7tiền game"));
        to.sendMessage(color("&7Thẻ " + money(amount) + "đ → &e" + money(Math.max(1, Math.round(amount * cardRate * (1 + promoRate)))) + " &7tiền game"));
        if (firstEnabled) {
            to.sendMessage(color("&7Nạp lần đầu (bank) → &e" + money(Math.max(1, Math.round(amount * bankRate * (1 + promoRate + firstRate)))) + " &7tiền game"));
        }
    }

    // ================= GIAO DIEN (GUI) =================

    private static class Gui implements InventoryHolder {
        Inventory inv;
        boolean used = false;
        final Map<Integer, Consumer<Player>> actions = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final Material[] TIERS = {
            Material.COPPER_INGOT, Material.IRON_INGOT, Material.GOLD_INGOT, Material.EMERALD,
            Material.DIAMOND, Material.NETHERITE_INGOT, Material.NETHER_STAR, Material.BEACON};

    private String g(String key, String def) {
        return getConfig().getString("gui." + key, def);
    }

    private Component lc(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(lc(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(lc(s));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    private int guiRows(int n) {
        return Math.max(1, Math.min(4, (n + 6) / 7));
    }

    private int guiSize(int n) {
        return (guiRows(n) + 2) * 9;
    }

    private Gui newGui(String title, int size) {
        Gui gui = new Gui();
        gui.inv = Bukkit.createInventory(gui, size, LegacyComponentSerializer.legacyAmpersand().deserialize(title));
        ItemStack pane = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < size; i++) gui.inv.setItem(i, pane);
        return gui;
    }

    private void put(Gui gui, int slot, ItemStack item, Consumer<Player> action) {
        gui.inv.setItem(slot, item);
        if (action != null) gui.actions.put(slot, action);
        else gui.actions.remove(slot);
    }

    /** Xep n o vao giua cac hang (cot 1-7, hang 1 tro di). */
    private int[] layout(int n) {
        int rows = guiRows(n);
        int[] out = new int[n];
        int idx = 0;
        for (int r = 0; r < rows; r++) {
            int k = n / rows + (r < n % rows ? 1 : 0);
            int start = 1 + (7 - k) / 2;
            for (int i = 0; i < k; i++) out[idx++] = 9 * (r + 1) + start + i;
        }
        return out;
    }

    private Material tier(int i, int n) {
        return TIERS[Math.min(TIERS.length - 1, i * TIERS.length / Math.max(1, n))];
    }

    private void clickSound(Player p) {
        if (getConfig().getBoolean("gui.sound", true)) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        }
    }

    private void openGui(Player p, Gui gui) {
        p.openInventory(gui.inv);
        clickSound(p);
    }

    private long gain(long amount, double rate) {
        return Math.max(1, Math.round(amount * rate));
    }

    // ---------- GUI nap ngan hang ----------

    private void openBankGui(Player p) {
        if (!checkBank(p)) return;
        FileConfiguration c = getConfig();
        final long min = c.getLong("order.min-amount", 10000);
        final long max = c.getLong("order.max-amount", 5000000);
        final double rate = c.getDouble("reward.money-rate", 1.0);

        List<Long> amounts = c.getLongList("gui.bank-amounts");
        if (amounts.isEmpty()) amounts = List.of(10000L, 20000L, 50000L, 100000L, 200000L, 500000L, 1000000L, 2000000L);
        final List<Long> list = amounts.stream().filter(a -> a >= min && a <= max).limit(28).collect(Collectors.toList());

        final int size = guiSize(list.size());
        final int fb = size - 9;
        Gui gui = newGui(g("bank-title", "&0Nạp tiền ngân hàng"), size);

        put(gui, 4, icon(Material.GOLD_BLOCK, "&6&lCARD2K",
                "&7Chuyển khoản qua &fVietQR",
                "&7Ngân hàng: &f" + c.getString("bank.bank-display-name", c.getString("bank.bank-id", "")),
                " ",
                "&7Nạp từ &f" + money(min) + "đ &7đến &f" + money(max) + "đ",
                "&7Quy đổi: &f1.000đ &7= &e" + money(gain(1000, rate)) + " &7tiền game"), null);

        int[] slots = layout(list.size());
        for (int i = 0; i < list.size(); i++) {
            final long a = list.get(i);
            put(gui, slots[i], icon(tier(i, list.size()), "&e&l" + money(a) + "đ",
                    "&7Nhận: &a" + money(previewGain(p, a, rate)) + " &7tiền game" + bonusTag(p),
                    " ",
                    "&6» &fBấm để tạo mã QR"),
                    pl -> {
                        pl.closeInventory();
                        createOrder(pl, String.valueOf(a));
                    });
        }

        // Hang duoi: nhap so khac / dong / lenh dang cho
        put(gui, fb + 2, icon(Material.OAK_SIGN, "&b&lNhập số khác",
                "&7Tự gõ số tiền bạn muốn nạp",
                "&7(từ &f" + money(min) + "đ &7đến &f" + money(max) + "đ&7)",
                " ",
                "&6» &fBấm rồi gõ số tiền vào chat"),
                pl -> {
                    pl.closeInventory();
                    amountPrompts.put(pl.getUniqueId(), System.currentTimeMillis());
                    tell(pl, "gui-custom-prompt", Map.of("min", money(min), "max", money(max),
                            "seconds", String.valueOf(getConfig().getInt("card.prompt-seconds", 60))));
                });

        put(gui, fb + 4, icon(Material.BARRIER, "&c&lĐóng"), Player::closeInventory);

        final Order pend = pendingOf(p.getUniqueId());
        if (pend != null) {
            put(gui, fb + 6, icon(Material.PAPER, "&e&lLệnh đang chờ",
                    "&7Mã: &6" + pend.code,
                    "&7Số tiền: &f" + money(pend.amount) + "đ",
                    " ",
                    "&6» &fBấm để xem lại mã QR"),
                    pl -> {
                        pl.closeInventory();
                        Order cur = pendingOf(pl.getUniqueId());
                        if (cur == null) tell(pl, "no-pending", null);
                        else showInstructions(pl, cur);
                    });
            put(gui, fb + 7, icon(Material.RED_DYE, "&c&lHủy lệnh đang chờ",
                    "&7Hủy lệnh &6" + pend.code,
                    " ",
                    "&6» &fBấm để hủy"),
                    pl -> {
                        pl.closeInventory();
                        cancelPending(pl);
                    });
        } else {
            put(gui, fb + 6, icon(Material.CLOCK, "&a&lTự động cộng tiền",
                    "&7Chuyển khoản xong chờ khoảng",
                    "&71 phút, tiền vào game tự động."), null);
        }
        openGui(p, gui);
    }

    // ---------- GUI nap the cao ----------

    private String telcoColor(String telco) {
        return switch (telco) {
            case "VIETTEL" -> "&c";
            case "VINAPHONE" -> "&9";
            case "MOBIFONE" -> "&3";
            case "VIETNAMOBILE" -> "&6";
            case "GMOBILE" -> "&8";
            case "ZING" -> "&d";
            case "GATE" -> "&b";
            case "GARENA" -> "&4";
            case "VCOIN" -> "&2";
            default -> "&e";
        };
    }

    private Material telcoMaterial(String telco) {
        return switch (telco) {
            case "VIETTEL" -> Material.RED_CONCRETE;
            case "VINAPHONE" -> Material.BLUE_CONCRETE;
            case "MOBIFONE" -> Material.CYAN_CONCRETE;
            case "VIETNAMOBILE" -> Material.ORANGE_CONCRETE;
            case "GMOBILE" -> Material.GRAY_CONCRETE;
            case "ZING" -> Material.MAGENTA_CONCRETE;
            case "GATE" -> Material.LIGHT_BLUE_CONCRETE;
            case "GARENA" -> Material.RED_TERRACOTTA;
            case "VCOIN" -> Material.GREEN_CONCRETE;
            default -> Material.PAPER;
        };
    }

    private String prettyTelco(String telco) {
        return telco.isEmpty() ? telco : telco.charAt(0) + telco.substring(1).toLowerCase(Locale.ROOT);
    }

    private void openTelcoGui(Player p) {
        FileConfiguration c = getConfig();
        if (!checkCard(p)) return;
        final List<String> telcos = cardTelcos();
        final int size = guiSize(telcos.size());
        final int fb = size - 9;
        Gui gui = newGui(g("card-telco-title", "&0Nạp thẻ cào &8» &0Chọn nhà mạng"), size);

        put(gui, 4, icon(Material.GOLD_BLOCK, "&6&lNẠP THẺ CÀO",
                "&7Bước 1/3: chọn &fnhà mạng",
                "&7Bước 2/3: chọn &fmệnh giá",
                "&7Bước 3/3: gõ &fserial &7và &fmã thẻ &7vào chat",
                " ",
                "&7Quy đổi: &f1.000đ &7= &e" + money(gain(1000, c.getDouble("card.money-rate", 1.0))) + " &7tiền game"), null);

        int[] slots = layout(telcos.size());
        for (int i = 0; i < telcos.size(); i++) {
            final String t = telcos.get(i);
            put(gui, slots[i], icon(telcoMaterial(t), telcoColor(t) + "&l" + prettyTelco(t),
                    "&7Nạp thẻ cào &f" + prettyTelco(t),
                    " ",
                    "&6» &fBấm để chọn mệnh giá"),
                    pl -> openCardAmountGui(pl, t));
        }
        put(gui, fb + 4, icon(Material.BARRIER, "&c&lĐóng"), Player::closeInventory);
        openGui(p, gui);
    }

    private void openCardAmountGui(Player p, String telco) {
        FileConfiguration c = getConfig();
        if (!checkCard(p)) return;
        final double rate = c.getDouble("card.money-rate", 1.0);
        final List<Long> amounts = cardAmounts(telco).stream().limit(28).collect(Collectors.toList());
        final int size = guiSize(amounts.size());
        final int fb = size - 9;
        Gui gui = newGui(g("card-amount-title", "&0Nạp thẻ {telco} &8» &0Chọn mệnh giá")
                .replace("{telco}", prettyTelco(telco)), size);

        put(gui, 4, icon(telcoMaterial(telco), telcoColor(telco) + "&l" + prettyTelco(telco),
                "&7Bước 2/3: chọn &fmệnh giá thẻ",
                "&7Chọn đúng mệnh giá in trên thẻ."), null);

        int[] slots = layout(amounts.size());
        for (int i = 0; i < amounts.size(); i++) {
            final long a = amounts.get(i);
            put(gui, slots[i], icon(tier(i, amounts.size()), "&e&l" + money(a) + "đ",
                    "&7Nhà mạng: &f" + prettyTelco(telco),
                    "&7Nhận: &a" + money(previewGain(p, a, rate)) + " &7tiền game" + bonusTag(p),
                    " ",
                    "&6» &fBấm rồi gõ serial & mã thẻ vào chat"),
                    pl -> {
                        pl.closeInventory();
                        startCardPrompt(pl, telco, a);
                    });
        }
        put(gui, fb + 2, icon(Material.ARROW, "&e&l« Quay lại", "&7Chọn lại nhà mạng"), pl -> openTelcoGui(pl));
        put(gui, fb + 4, icon(Material.BARRIER, "&c&lĐóng"), Player::closeInventory);
        put(gui, fb + 6, icon(Material.PAPER, "&c&lLưu ý",
                "&7Chọn đúng mệnh giá của thẻ.",
                "&7Sai mệnh giá có thể bị tính",
                "&7ít hơn hoặc không được cộng."), null);
        openGui(p, gui);
    }

    // ---------- Su kien GUI ----------

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Gui gui)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        Consumer<Player> action = gui.actions.get(e.getSlot());
        if (action == null || gui.used) return;
        gui.used = true; // chong bam 2 lan
        clickSound(p);
        Bukkit.getScheduler().runTask(this, () -> action.accept(p));
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("khuyenmai")) return out;
        if (cmd.getName().equalsIgnoreCase("napthe")) {
            if (args.length == 1) {
                out.addAll(cardTelcos());
                out.add("huy");
            } else if (args.length == 2) {
                for (Long a : getConfig().getLongList("card.amounts")) out.add(String.valueOf(a));
            }
            return out.stream().filter(x -> x.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (cmd.getName().equalsIgnoreCase("card2k")) {
            if (args.length == 1 && sender.hasPermission("card2k.admin")) out.addAll(List.of("reload", "pending", "status", "update", "testpoint"));
        } else if (args.length == 1) {
            out.addAll(List.of("menu", "50000", "100000", "huy"));
            if (sender.hasPermission("card2k.admin")) out.addAll(List.of("reload", "pending", "status", "update", "testpoint"));
        }
        return out.stream().filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .collect(Collectors.toList());
    }
}
